# ProView Reputation API (Action-ready)

Minimal reputation aggregation API for ProView (Custom GPT Action). 
Combines **Google Safe Browsing** (blocklist), **VirusTotal** (malicious ratio), **WHOIS** (domain age), and **Tranco** (popularity) with **caching + stale-while-revalidate**.

## Features
- **Shades of trust**: returns `score (0–100)` and `verdict` = allow/medium/caution/block
- **Caching** (Redis or in-memory) with **SWR**
- **Rate-limit aware**: calls VirusTotal only when GSB is clean
- **Admin**: `/admin/flush`, `/admin/stats`
- **Action-ready**: `openapi.yaml` and `actions-manifest.json` included

## Quick start
```bash
git clone <this-zip-extracted-folder>
cd proview-reputation-api
cp .env.example .env
npm i
npm run start
```

Set any provider keys you have in `.env`. Without keys, the API will still run but return `unknown` for some signals.

### Environment
- `PORT` (default 8080)
- `REDIS_URL` (optional; if not set, falls back to in-memory cache)
- `GSB_API_KEY` (Google Safe Browsing)
- `VT_API_KEY` (VirusTotal)
- `WHOIS_API_KEY` (WhoisAPI)
- `TRANCO_URL` (CSV `rank,domain`)

## Endpoints
- `POST /reputation` → `{ score, verdict, signals[], reasons[], lastAggregatedAt, swrUntil }`
- `POST /admin/flush` → `{ ok, flushed }`
- `GET /admin/stats` → `{ cache, now }`

## Scoring (default)
- GSB unsafe → force `block` (~20).
- VT malicious ratio < 0.1 → +20; otherwise −30.
- WHOIS age >3y → +15; <1y → −10.
- Tranco rank < 500k → +10; missing → −5.
- Clamp to 0–100; map to verdicts: 
  - 80–100 allow, 60–79 medium, 30–59 caution, <30 block.

## OpenAI Custom GPT (Actions)
1. Host this API at `https://YOUR_DOMAIN_OR_TUNNEL/reputation-api`.
2. Update `openapi.yaml` and `actions-manifest.json` with your URL.
3. In GPT Builder → **Actions** → import `openapi.yaml`.
4. (Optional) Add domain verification + privacy policy for public listing.

## Caching strategy
- **FRESH_TTL_DAYS** (default 14): serve without re-fetch.
- **MAX_STALE_DAYS** (default 60): serve stale while background refresh runs.
- Provider TTL guidance:
  - GSB: 24h
  - VT: 7–14d
  - WHOIS: 180d
  - Tranco: 30d

## Notes
- This project intentionally avoids provider SDKs; it uses HTTP only.
- Replace or extend providers as needed (e.g., IPQS).

## License
MIT
