import fetch from "node-fetch";

let cache = new Map();
let loaded = false;

export async function checkTranco(domain) {
  const src = process.env.TRANCO_URL;
  if (!src) return { rank: null, checkedAt: new Date().toISOString(), why: "no-list" };
  if (!loaded) {
    try {
      const r = await fetch(src);
      const txt = await r.text();
      // Expect CSV: rank,domain
      for (const line of txt.split(/\r?\n/)) {
        const [rank, d] = line.split(",");
        if (!rank || !d) continue;
        cache.set(d.trim(), parseInt(rank,10));
      }
      loaded = true;
    } catch (e) {
      return { rank: null, error: "load-failed", checkedAt: new Date().toISOString() };
    }
  }
  const rank = cache.get(domain) || null;
  return { rank, checkedAt: new Date().toISOString() };
}
