import fetch from "node-fetch";

// VirusTotal URL lookup: requires URL ID (base64url of the URL). We approximate by querying the domain with domain report.
// This keeps usage simple and free-tier friendly.
export async function checkVT(targetDomain) {
  const key = process.env.VT_API_KEY;
  if (!key) return { ratio: null, checkedAt: new Date().toISOString(), why: "no-key" };
  const r = await fetch(`https://www.virustotal.com/api/v3/domains/${encodeURIComponent(targetDomain)}`, {
    headers: { "x-apikey": key }
  });
  if (!r.ok) {
    const txt = await r.text();
    return { ratio: null, error: `vt:${r.status}`, details: txt, checkedAt: new Date().toISOString() };
  }
  const data = await r.json();
  const stats = data?.data?.attributes?.last_analysis_stats;
  if (!stats) return { ratio: null, checkedAt: new Date().toISOString() };
  const total = Object.values(stats).reduce((a,b)=>a+b,0) || 1;
  const malicious = (stats.malicious || 0) + (stats.suspicious || 0);
  const ratio = malicious / total;
  return { ratio, checkedAt: new Date().toISOString(), raw: stats };
}
