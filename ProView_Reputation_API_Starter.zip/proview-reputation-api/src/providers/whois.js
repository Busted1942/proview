import fetch from "node-fetch";

export async function checkWHOIS(domain) {
  const key = process.env.WHOIS_API_KEY;
  if (!key) return { ageYears: null, checkedAt: new Date().toISOString(), why: "no-key" };
  const url = `https://www.whoisxmlapi.com/whoisserver/WhoisService?domainName=${encodeURIComponent(domain)}&apiKey=${key}&outputFormat=JSON`;
  const r = await fetch(url);
  if (!r.ok) {
    const txt = await r.text();
    return { ageYears: null, error: `whois:${r.status}`, details: txt, checkedAt: new Date().toISOString() };
  }
  const data = await r.json();
  const created = data?.WhoisRecord?.createdDateNormalized || data?.WhoisRecord?.registryData?.createdDateNormalized;
  const createdAt = created ? new Date(created) : null;
  let ageYears = null;
  if (createdAt && !isNaN(createdAt)) {
    const ms = Date.now() - createdAt.getTime();
    ageYears = ms / (365.25 * 24 * 3600 * 1000);
  }
  return { ageYears, checkedAt: new Date().toISOString(), createdAt };
}
