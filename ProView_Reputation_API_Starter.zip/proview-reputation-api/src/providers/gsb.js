import fetch from "node-fetch";

export async function checkGSB(target) {
  const key = process.env.GSB_API_KEY;
  if (!key) {
    return { unsafe: false, why: "no-key" };
  }
  const url = `https://safebrowsing.googleapis.com/v4/threatMatches:find?key=${key}`;
  const body = {
    client: { clientId: "proview", clientVersion: "1.0" },
    threatInfo: {
      threatTypes: ["MALWARE","SOCIAL_ENGINEERING","UNWANTED_SOFTWARE","POTENTIALLY_HARMFUL_APPLICATION"],
      platformTypes: ["ANY_PLATFORM"],
      threatEntryTypes: ["URL"],
      threatEntries: [{ url: target }]
    }
  };
  const r = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
  if (!r.ok) {
    const txt = await r.text();
    return { unsafe: false, why: `error:${r.status}`, error: txt };
  }
  const data = await r.json();
  const unsafe = !!(data.matches && data.matches.length);
  return { unsafe, matches: data.matches || [] };
}
