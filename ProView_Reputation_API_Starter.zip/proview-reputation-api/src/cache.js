import Redis from "ioredis";

const IN_MEMORY = new Map();
let redis = null;

export function initCache() {
  const url = process.env.REDIS_URL;
  if (url) {
    redis = new Redis(url);
    redis.on("error", (e) => console.error("[redis] error", e.message));
    console.log("[cache] Using Redis");
  } else {
    console.log("[cache] Using in-memory cache");
  }
}

export async function get(key) {
  if (redis) {
    const v = await redis.get(key);
    return v ? JSON.parse(v) : null;
  }
  const v = IN_MEMORY.get(key);
  return v ?? null;
}

export async function set(key, value, ttlSec) {
  const str = JSON.stringify(value);
  if (redis) {
    await redis.set(key, str, "EX", ttlSec);
  } else {
    IN_MEMORY.set(key, value);
    // simple in-memory TTL
    setTimeout(() => IN_MEMORY.delete(key), ttlSec * 1000).unref?.();
  }
}

export async function del(key) {
  if (redis) return redis.del(key);
  return IN_MEMORY.delete(key);
}

export function stats() {
  return {
    backend: redis ? "redis" : "memory",
    keys: redis ? "n/a" : IN_MEMORY.size
  };
}
