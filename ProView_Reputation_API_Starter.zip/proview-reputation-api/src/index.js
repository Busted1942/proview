import express from "express";
import dotenv from "dotenv";
import { parse as parseTld } from "tldts";
import { initCache, get as cacheGet, set as cacheSet, del as cacheDel, stats as cacheStats } from "./cache.js";
import { checkGSB } from "./providers/gsb.js";
import { checkVT } from "./providers/vt.js";
import { checkWHOIS } from "./providers/whois.js";
import { checkTranco } from "./providers/tranco.js";

dotenv.config();
const app = express();
app.use(express.json());

initCache();

// Tunables
const FRESH_TTL_DAYS = parseInt(process.env.FRESH_TTL_DAYS || "14", 10);
const MAX_STALE_DAYS = parseInt(process.env.MAX_STALE_DAYS || "60", 10);

function registrable(domainOrUrl) {
  try {
    const d = parseTld(domainOrUrl);
    return d.domain || null;
  } catch {
    return null;
  }
}

function clamp(n, a, b){ return Math.max(a, Math.min(b, n)); }

async function compute(target) {
  const reg = registrable(target);
  const nowIso = new Date().toISOString();
  const signals = [];

  // Providers (best-effort; skip gracefully on errors)
  const gsb = await checkGSB(target).catch(()=>({ unsafe: false, why: "error" }));
  signals.push({ provider: "gsb", status: gsb.unsafe ? "unsafe" : "clean", checkedAt: nowIso });

  let vt = { ratio: null, checkedAt: nowIso };
  // Only call VT if GSB is clean to conserve quota
  if (!gsb.unsafe) {
    vt = await checkVT(reg).catch(()=>({ ratio: null, checkedAt: nowIso }));
    signals.push({ provider: "vt", maliciousRatio: vt.ratio, checkedAt: vt.checkedAt });
  } else {
    signals.push({ provider: "vt", maliciousRatio: null, checkedAt: nowIso, skipped: true });
  }

  const who = await checkWHOIS(reg).catch(()=>({ ageYears: null, checkedAt: nowIso }));
  signals.push({ provider: "whois", ageYears: who.ageYears, checkedAt: who.checkedAt });

  const tra = await checkTranco(reg).catch(()=>({ rank: null, checkedAt: nowIso }));
  signals.push({ provider: "tranco", rank: tra.rank, checkedAt: tra.checkedAt });

  // Aggregate
  let score = 100;
  const reasons = [];
  if (gsb.unsafe) {
    score = 20; reasons.push("Flagged by Google Safe Browsing");
  } else {
    if (vt.ratio != null) { score += vt.ratio < 0.1 ? 20 : -30; }
    if (who.ageYears != null) { score += who.ageYears > 3 ? 15 : (who.ageYears < 1 ? -10 : 0); }
    if (tra.rank != null) { score += tra.rank < 500000 ? 10 : -5; } else { reasons.push("No popularity data"); }
  }
  score = clamp(score, 0, 100);
  const verdict = score >= 80 ? "allow" : score >= 60 ? "medium" : score >= 30 ? "caution" : "block";

  return {
    score, verdict, signals, reasons,
    lastAggregatedAt: nowIso
  };
}

const keyFor = (regDomain) => regDomain ? `rep:v1:${regDomain}` : null;

function swrUntil(ts, days) {
  return new Date(new Date(ts).getTime() + days*864e5).toISOString();
}

app.post("/reputation", async (req, res) => {
  const { target } = req.body || {};
  if (!target) return res.status(400).json({ error: "target required" });

  const reg = registrable(target);
  if (!reg) return res.status(400).json({ error: "invalid domain or url" });

  const key = keyFor(reg);
  const cached = await cacheGet(key);

  if (cached && new Date(cached.swrUntil) > new Date()) {
    return res.json({ ...cached, cached: true, freshness: "fresh" });
  }

  // Serve stale while revalidating
  if (cached) {
    res.json({ ...cached, cached: true, freshness: "stale" });
    compute(target).then(async (result) => {
      const nowIso = new Date().toISOString();
      const out = { ...result, swrUntil: swrUntil(nowIso, FRESH_TTL_DAYS) };
      await cacheSet(key, out, MAX_STALE_DAYS * 86400);
    }).catch(()=>{});
    return;
  }

  // No cache: compute now
  const result = await compute(target);
  const nowIso = new Date().toISOString();
  const out = { ...result, swrUntil: swrUntil(nowIso, FRESH_TTL_DAYS) };
  await cacheSet(key, out, MAX_STALE_DAYS * 86400);
  res.json({ ...out, cached: false, freshness: "new" });
});

// Admin endpoints
app.post("/admin/flush", async (req, res) => {
  const { domain } = req.body || {};
  if (!domain) return res.status(400).json({ error: "domain required" });
  const reg = registrable(domain);
  if (!reg) return res.status(400).json({ error: "invalid domain" });
  await cacheDel(keyFor(reg));
  res.json({ ok: true, flushed: reg });
});

app.get("/admin/stats", (req, res) => {
  res.json({ cache: cacheStats(), now: new Date().toISOString() });
});

const port = process.env.PORT || 8080;
app.listen(port, () => {
  console.log(`[proview-reputation-api] listening on :${port}`);
});
